# DEPLOY (prod quick)
- Provision VM, install Docker & docker compose
- Configure DNS + reverse proxy (nginx-proxy / Traefik) with TLS
- `docker compose -f docker-compose.yml up -d --build`
- Set env in backend/.env (STRIPE, webhooks, notifications)
- Add backups (nightly Postgres dump), monitoring (health checks), and logs aggregation
