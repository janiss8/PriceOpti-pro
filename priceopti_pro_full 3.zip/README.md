# PriceOpti Pro+ — Production-lean Pricing SaaS

**Stack**
- Backend: FastAPI, SQLAlchemy, JWT, Celery + Redis (autopilot agent), Postgres-ready, Stripe billing, Shopify/Woo webhooks, CSV competitor feeds, Slack/Email alerts.
- Frontend: React (Vite/TS), Tailwind. Views: Auth, Dashboard, Products, Suggestions, Experiments (A/B), Settings, Competitors, Billing.
- DevOps: Docker Compose (api, worker, beat, web, redis, postgres).

## Quickstart (Docker)
```bash
docker compose up --build
# API docs: http://localhost:8000/docs
# Frontend: http://localhost:5173
```
(Manual run supported; see backend/README snippets.)

## Notes
- Set secrets in `backend/.env` (copy from `.env.example`).
- Stripe keys required for real checkout; else Billing button will show an error.
- Shopify/Woo connectors are implemented with real endpoint shapes; add your credentials to use.
