from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List, Optional, Dict
from database import get_db
from deps import get_current_user
from models import Product, PriceSuggestion, Shop, CompetitorPrice
from schemas import SuggestionOut
from price_engine import suggest_price

router=APIRouter(prefix="/agent", tags=["agent"])

@router.post("/run", response_model=List[SuggestionOut])
def run_agent(shop_id: Optional[int]=None, db: Session = Depends(get_db), user=Depends(get_current_user)):
    q=db.query(Product).join(Shop).filter(Shop.owner_id==user.id)
    if shop_id: q=q.filter(Product.shop_id==shop_id)
    products=q.all(); results=[]
    for p in products:
        comp=db.query(CompetitorPrice).filter(CompetitorPrice.shop_id==p.shop_id, CompetitorPrice.sku==p.sku).order_by(CompetitorPrice.updated_at.desc()).first()
        competitor_price=comp.price if comp else None
        metrics={"competitor_price": competitor_price, "demand_score":0.5, "stock_pressure":0.2, "margin_target":0.35, "max_increase_pct":0.15, "max_discount_pct":0.20}
        suggested, rationale=suggest_price(p, metrics)
        s=PriceSuggestion(product_id=p.id, current_price=p.price, suggested_price=suggested, rationale=rationale, approved=False)
        db.add(s); db.commit(); db.refresh(s); results.append(s)
    return results
