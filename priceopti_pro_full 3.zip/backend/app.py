from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from dotenv import load_dotenv
import os
from database import Base, engine, get_db
from models import User, Shop, Product, PriceSuggestion, Experiment, ExperimentVariant
from schemas import ShopCreate, ShopOut, ShopUpdate, ProductCreate, ProductOut, SuggestionOut, ExperimentCreate, ExperimentVariantCreate
from auth import router as auth_router
from agent import router as agent_router
from deps import get_current_user
from tasks import autopilot_tick
from competitors import router as competitors_router
from billing import router as billing_router
from webhooks import router as webhooks_router

load_dotenv()
app=FastAPI(title="PriceOpti Pro+ API", version="0.3.0")

allow_origins=os.getenv("ALLOW_ORIGINS","http://localhost:5173").split(",")
app.add_middleware(CORSMiddleware, allow_origins=allow_origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

Base.metadata.create_all(bind=engine)

@app.get("/health")
def health(): return {"status":"ok"}

app.include_router(auth_router)
app.include_router(agent_router)
app.include_router(competitors_router)
app.include_router(billing_router)
app.include_router(webhooks_router)

@app.post("/shops", response_model=ShopOut)
def create_shop(payload: ShopCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    shop=Shop(**payload.dict(), owner_id=user.id); db.add(shop); db.commit(); db.refresh(shop); return shop

@app.get("/shops", response_model=list[ShopOut])
def list_shops(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Shop).filter(Shop.owner_id==user.id).all()

@app.put("/shops/{shop_id}", response_model=ShopOut)
def update_shop(shop_id: int, payload: ShopUpdate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    shop=db.query(Shop).filter(Shop.id==shop_id, Shop.owner_id==user.id).first()
    if not shop: raise HTTPException(404,"Shop not found")
    for k,v in payload.dict(exclude_unset=True).items(): setattr(shop, k, v)
    db.commit(); db.refresh(shop); return shop

@app.post("/products", response_model=ProductOut)
def create_product(payload: ProductCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    shop=db.query(Shop).filter(Shop.id==payload.shop_id, Shop.owner_id==user.id).first()
    if not shop: raise HTTPException(403,"Not your shop")
    p=Product(**payload.dict()); db.add(p); db.commit(); db.refresh(p); return p

@app.get("/products", response_model=list[ProductOut])
def list_products(shop_id: int | None = None, db: Session = Depends(get_db), user=Depends(get_current_user)):
    q=db.query(Product).join(Shop).filter(Shop.owner_id==user.id)
    if shop_id: q=q.filter(Product.shop_id==shop_id)
    return q.all()

@app.get("/suggestions", response_model=list[SuggestionOut])
def list_suggestions(shop_id: int | None = None, db: Session = Depends(get_db), user=Depends(get_current_user)):
    q=db.query(PriceSuggestion).join(PriceSuggestion.product).join(Product.shop).filter(Shop.owner_id==user.id)
    if shop_id: q=q.filter(Product.shop_id==shop_id)
    return q.order_by(PriceSuggestion.created_at.desc()).limit(300).all()

@app.post("/suggestions/{suggestion_id}/approve", response_model=SuggestionOut)
def approve_suggestion(suggestion_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    s=db.query(PriceSuggestion).get(suggestion_id)
    if not s: raise HTTPException(404,"Not found")
    if s.product.shop.owner_id != user.id: raise HTTPException(403,"Forbidden")
    s.approved=True; s.product.price=s.suggested_price; db.commit(); db.refresh(s); return s

@app.post("/experiments", response_model=dict)
def create_experiment(payload: ExperimentCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    shop=db.query(Shop).filter(Shop.id==payload.shop_id, Shop.owner_id==user.id).first()
    if not shop: raise HTTPException(403,"Not your shop")
    exp=Experiment(shop_id=shop.id, name=payload.name, active=True); db.add(exp); db.commit(); db.refresh(exp); return {"id":exp.id,"name":exp.name}

@app.post("/experiments/variant", response_model=dict)
def add_variant(payload: ExperimentVariantCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    exp=db.query(Experiment).get(payload.experiment_id)
    if not exp or exp.shop.owner_id != user.id: raise HTTPException(403,"Forbidden")
    var=ExperimentVariant(experiment_id=exp.id, label=payload.label, price_delta_pct=payload.price_delta_pct, traffic_split=payload.traffic_split)
    db.add(var); db.commit(); db.refresh(var); return {"id":var.id,"label":var.label}
