from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from passlib.context import CryptContext
from jose import jwt, JWTError
from datetime import datetime, timedelta
from typing import Optional
import os
from database import get_db
from models import User
from schemas import UserCreate, Token

SECRET_KEY=os.getenv("SECRET_KEY","change_me")
ALGORITHM="HS256"
ACCESS_TOKEN_EXPIRE_MINUTES=int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES","120"))
pwd_context=CryptContext(schemes=["bcrypt"], deprecated="auto")
router=APIRouter(prefix="/auth", tags=["auth"])

def verify_password(p, h): return pwd_context.verify(p, h)
def get_hash(p): return pwd_context.hash(p)
def make_token(data: dict, expires: Optional[timedelta]=None):
    to_encode=data.copy(); exp=datetime.utcnow()+(expires or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp":exp}); return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

@router.post("/register", response_model=Token)
def register(payload: UserCreate, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email==payload.email).first(): raise HTTPException(400,"Email already registered")
    u=User(email=payload.email, password_hash=get_hash(payload.password)); db.add(u); db.commit(); db.refresh(u)
    return Token(access_token=make_token({"sub":str(u.id),"email":u.email}))

@router.post("/login", response_model=Token)
def login(payload: UserCreate, db: Session = Depends(get_db)):
    u=db.query(User).filter(User.email==payload.email).first()
    if not u or not verify_password(payload.password, u.password_hash): raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    return Token(access_token=make_token({"sub":str(u.id),"email":u.email}))
