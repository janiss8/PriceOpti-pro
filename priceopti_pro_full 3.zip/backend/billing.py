import os, stripe
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from database import get_db
from deps import get_current_user
from models import Subscription

router=APIRouter(prefix="/billing", tags=["billing"])
stripe.api_key=os.getenv("STRIPE_API_KEY","")
PRICE_BASIC=os.getenv("STRIPE_PRICE_BASIC","")
WEBHOOK_SECRET=os.getenv("STRIPE_WEBHOOK_SECRET","")

@router.post("/checkout")
def create_checkout_session(db: Session = Depends(get_db), user=Depends(get_current_user)):
    if not stripe.api_key or not PRICE_BASIC: raise HTTPException(400,"Stripe not configured")
    session=stripe.checkout.Session.create(mode="subscription", line_items=[{"price":PRICE_BASIC,"quantity":1}], success_url="http://localhost:5173?status=success", cancel_url="http://localhost:5173?status=cancel")
    return {"checkout_url": session.url}

@router.post("/webhook")
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    payload=await request.body(); sig=request.headers.get("stripe-signature")
    try: event=stripe.Webhook.construct_event(payload, sig, WEBHOOK_SECRET)
    except Exception as e: raise HTTPException(400, str(e))
    et=event["type"]; data=event["data"]["object"]
    if et=="checkout.session.completed":
        db.add(Subscription(user_id=None, stripe_customer_id=data.get("customer"), stripe_subscription_id=data.get("subscription"), plan="basic", status="active")); db.commit()
    elif et=="customer.subscription.updated":
        sub=db.query(Subscription).filter(Subscription.stripe_subscription_id==data.get("id")).first()
        if sub: sub.status=data.get("status"); db.commit()
    return {"ok": True}
