from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from sqlalchemy.orm import Session
import csv, io
from typing import Optional
from database import get_db
from deps import get_current_user
from models import Shop, CompetitorPrice

router=APIRouter(prefix="/competitors", tags=["competitors"])

@router.post("/upload")
async def upload_csv(shop_id: int, file: UploadFile = File(...), db: Session = Depends(get_db), user=Depends(get_current_user)):
    shop=db.query(Shop).filter(Shop.id==shop_id, Shop.owner_id==user.id).first()
    if not shop: raise HTTPException(403, "Not your shop")
    content=await file.read()
    reader=csv.DictReader(io.StringIO(content.decode("utf-8")))
    count=0
    for row in reader:
        sku=row.get("sku") or row.get("SKU")
        price=row.get("price") or row.get("competitor_price")
        comp=row.get("competitor") or "unknown"
        if not sku or not price: continue
        try: price=float(price)
        except: continue
        db.add(CompetitorPrice(shop_id=shop.id, sku=sku, competitor=comp, price=price)); count+=1
    db.commit(); return {"ok": True, "rows": count}

@router.get("")
def list_competitors(shop_id: Optional[int]=None, db: Session = Depends(get_db), user=Depends(get_current_user)):
    q=db.query(CompetitorPrice).join(Shop, CompetitorPrice.shop_id==Shop.id).filter(Shop.owner_id==user.id)
    if shop_id: q=q.filter(CompetitorPrice.shop_id==shop_id)
    items=q.order_by(CompetitorPrice.updated_at.desc()).limit(500).all()
    return [{"sku":i.sku,"competitor":i.competitor,"price":i.price,"updated_at":i.updated_at.isoformat()} for i in items]
