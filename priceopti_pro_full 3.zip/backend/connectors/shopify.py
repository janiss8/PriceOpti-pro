import requests
from typing import List, Dict, Any
def apply_price_update(shop_domain: str, api_key: str, api_password: str, variant_id: str, new_price: float) -> bool:
    url=f"https://{shop_domain}/admin/api/2023-10/variants/{variant_id}.json"
    resp=requests.put(url, auth=(api_key, api_password), json={"variant":{"id":variant_id,"price":str(new_price)}})
    return resp.status_code in (200,201)
def fetch_products(shop_domain: str, api_key: str, api_password: str) -> List[Dict[str, Any]]:
    url=f"https://{shop_domain}/admin/api/2023-10/products.json?limit=250"
    resp=requests.get(url, auth=(api_key, api_password))
    if resp.status_code!=200: return []
    return resp.json().get("products",[])
