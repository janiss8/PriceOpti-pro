import requests
from typing import List, Dict, Any
def apply_price_update(base_url: str, consumer_key: str, consumer_secret: str, product_id: str, new_price: float) -> bool:
    url=f"{base_url}/wp-json/wc/v3/products/{product_id}"
    resp=requests.put(url, params={"consumer_key":consumer_key,"consumer_secret":consumer_secret}, json={"regular_price":str(new_price)})
    return resp.status_code in (200,201)
def fetch_products(base_url: str, consumer_key: str, consumer_secret: str) -> List[Dict[str, Any]]:
    url=f"{base_url}/wp-json/wc/v3/products"
    resp=requests.get(url, params={"consumer_key":consumer_key,"consumer_secret":consumer_secret})
    if resp.status_code!=200: return []
    return resp.json()
