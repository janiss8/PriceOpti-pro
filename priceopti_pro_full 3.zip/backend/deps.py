from fastapi import Depends, HTTPException, status
from sqlalchemy.orm import Session
from jose import jwt, JWTError
import os
from database import get_db
from models import User

SECRET_KEY=os.getenv("SECRET_KEY","change_me")
ALGORITHM="HS256"

def get_current_user(db: Session = Depends(get_db), authorization: str = None):
    if not authorization or not authorization.startswith("Bearer "): raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing token")
    token=authorization.split(" ",1)[1]
    try:
        payload=jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM]); uid=payload.get("sub")
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
    user=db.query(User).get(int(uid))
    if not user: raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found")
    return user
