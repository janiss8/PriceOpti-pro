from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from database import Base

class User(Base):
    __tablename__="users"
    id=Column(Integer, primary_key=True, index=True)
    email=Column(String, unique=True, index=True, nullable=False)
    password_hash=Column(String, nullable=False)
    created_at=Column(DateTime, default=datetime.utcnow)
    shops=relationship("Shop", back_populates="owner")

class Shop(Base):
    __tablename__="shops"
    id=Column(Integer, primary_key=True, index=True)
    name=Column(String, nullable=False)
    platform=Column(String, nullable=True)
    api_key=Column(String, nullable=True)
    api_secret=Column(String, nullable=True)
    owner_id=Column(Integer, ForeignKey("users.id"))
    currency=Column(String, default="CHF")
    # Autopilot
    autopilot_enabled=Column(Boolean, default=False)
    auto_approve=Column(Boolean, default=False)
    max_increase_pct=Column(Float, default=0.10)
    max_discount_pct=Column(Float, default=0.15)
    margin_floor=Column(Float, default=0.25)
    # Notifications
    slack_webhook_url=Column(String, nullable=True)
    notify_email=Column(String, nullable=True)
    large_change_threshold=Column(Float, default=0.15)

    owner=relationship("User", back_populates="shops")
    products=relationship("Product", back_populates="shop")
    experiments=relationship("Experiment", back_populates="shop")

class Product(Base):
    __tablename__="products"
    id=Column(Integer, primary_key=True, index=True)
    shop_id=Column(Integer, ForeignKey("shops.id"))
    sku=Column(String, index=True, nullable=False)
    name=Column(String, nullable=False)
    cost=Column(Float, default=0.0)
    price=Column(Float, default=0.0)
    min_price=Column(Float, default=0.0)
    max_price=Column(Float, default=0.0)
    stock=Column(Integer, default=0)
    category=Column(String, default="general")
    shop=relationship("Shop", back_populates="products")
    suggestions=relationship("PriceSuggestion", back_populates="product")

class PriceSuggestion(Base):
    __tablename__="price_suggestions"
    id=Column(Integer, primary_key=True, index=True)
    product_id=Column(Integer, ForeignKey("products.id"))
    current_price=Column(Float, nullable=False)
    suggested_price=Column(Float, nullable=False)
    rationale=Column(Text, nullable=True)
    approved=Column(Boolean, default=False)
    created_at=Column(DateTime, default=datetime.utcnow)
    product=relationship("Product", back_populates="suggestions")

class Experiment(Base):
    __tablename__="experiments"
    id=Column(Integer, primary_key=True, index=True)
    shop_id=Column(Integer, ForeignKey("shops.id"))
    name=Column(String, nullable=False)
    active=Column(Boolean, default=True)
    created_at=Column(DateTime, default=datetime.utcnow)
    shop=relationship("Shop", back_populates="experiments")
    variants=relationship("ExperimentVariant", back_populates="experiment")

class ExperimentVariant(Base):
    __tablename__="experiment_variants"
    id=Column(Integer, primary_key=True, index=True)
    experiment_id=Column(Integer, ForeignKey("experiments.id"))
    label=Column(String, nullable=False)
    price_delta_pct=Column(Float, default=0.0)
    traffic_split=Column(Float, default=0.5)
    experiment=relationship("Experiment", back_populates="variants")

class Subscription(Base):
    __tablename__="subscriptions"
    id=Column(Integer, primary_key=True, index=True)
    user_id=Column(Integer, ForeignKey("users.id"))
    stripe_customer_id=Column(String, nullable=True)
    stripe_subscription_id=Column(String, nullable=True)
    plan=Column(String, nullable=True)
    status=Column(String, default="inactive")
    current_period_end=Column(DateTime, nullable=True)

class CompetitorPrice(Base):
    __tablename__="competitor_prices"
    id=Column(Integer, primary_key=True, index=True)
    shop_id=Column(Integer, ForeignKey("shops.id"))
    sku=Column(String, index=True, nullable=False)
    competitor=Column(String, nullable=True)
    price=Column(Float, nullable=False)
    updated_at=Column(DateTime, default=datetime.utcnow)

class EventLog(Base):
    __tablename__="event_logs"
    id=Column(Integer, primary_key=True, index=True)
    shop_id=Column(Integer, ForeignKey("shops.id"), nullable=True)
    type=Column(String, nullable=False)
    message=Column(Text, nullable=True)
    created_at=Column(DateTime, default=datetime.utcnow)
