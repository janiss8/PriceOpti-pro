import os, smtplib, requests
from email.mime_text import MIMEText  # type: ignore
# Fallback import name correction
try:
    from email.mime.text import MIMEText as _MIMEText
except Exception:
    from email.mime_text import MIMEText as _MIMEText  # pyright: ignore

def send_slack(text: str, webhook_url: str | None = None):
    url = webhook_url or os.getenv("SLACK_WEBHOOK_URL","")
    if not url: return False
    try:
        requests.post(url, json={"text": text}, timeout=5)
        return True
    except Exception:
        return False

def send_email(subject: str, body: str, to_email: str | None = None):
    host=os.getenv("SMTP_HOST"); user=os.getenv("SMTP_USER"); pwd=os.getenv("SMTP_PASS")
    port=int(os.getenv("SMTP_PORT","587")); sender=os.getenv("SMTP_FROM","alerts@priceopti.ai")
    if not (host and user and pwd and to_email): return False
    msg=_MIMEText(body,"plain","utf-8"); msg["Subject"]=subject; msg["From"]=sender; msg["To"]=to_email
    try:
        s=smtplib.SMTP(host,port,timeout=10); s.starttls(); s.login(user,pwd); s.sendmail(sender,[to_email],msg.as_string()); s.quit(); return True
    except Exception:
        return False
