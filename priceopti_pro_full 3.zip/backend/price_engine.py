from typing import Dict, Tuple
from models import Product
def suggest_price(product: Product, metrics: Dict) -> Tuple[float, str]:
    cp=metrics.get("competitor_price")
    demand=float(metrics.get("demand_score",0.5))
    stock_pressure=float(metrics.get("stock_pressure",0.2))
    margin_target=float(metrics.get("margin_target",0.3))
    max_inc=float(metrics.get("max_increase_pct",0.15))
    max_disc=float(metrics.get("max_discount_pct",0.20))
    base=product.price if product.price>0 else product.cost*(1+margin_target)
    parts=[]
    min_allowed=max(product.min_price, product.cost*(1+max(0.05, margin_target*0.8)))
    max_allowed=product.max_price if product.max_price>0 else base*(1+max_inc)
    if cp:
        if demand<0.4:
            target=cp*0.98; parts.append(f"Weak demand → 2% under competitor ({cp:.2f}).")
        else:
            target=cp*1.00; parts.append(f"Healthy demand → align with competitor ({cp:.2f}).")
        base=(base*0.5)+(target*0.5)
    else:
        if demand>=0.7: base*=1+min(max_inc,0.10); parts.append("High demand → small increase.")
        elif demand<=0.3: base*=1-min(max_disc,0.10); parts.append("Low demand → small discount.")
    if stock_pressure>0.7: base*=1-min(max_disc,0.20); parts.append("Stock pressure → clearance discount.")
    suggested=max(min_allowed, min(max_allowed, base)); parts.append(f"Bounds {min_allowed:.2f}–{max_allowed:.2f}. Cost={product.cost:.2f}, target margin≈{margin_target*100:.0f}%.")
    return round(suggested,2), " ".join(parts)
