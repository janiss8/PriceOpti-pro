from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

class UserCreate(BaseModel):
    email: EmailStr
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class ShopCreate(BaseModel):
    name: str
    platform: Optional[str] = None
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    currency: Optional[str] = "CHF"
    autopilot_enabled: Optional[bool] = False
    auto_approve: Optional[bool] = False
    max_increase_pct: Optional[float] = 0.10
    max_discount_pct: Optional[float] = 0.15
    margin_floor: Optional[float] = 0.25
    slack_webhook_url: Optional[str] = None
    notify_email: Optional[str] = None
    large_change_threshold: Optional[float] = 0.15

class ShopUpdate(BaseModel):
    name: Optional[str] = None
    platform: Optional[str] = None
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    currency: Optional[str] = None
    autopilot_enabled: Optional[bool] = None
    auto_approve: Optional[bool] = None
    max_increase_pct: Optional[float] = None
    max_discount_pct: Optional[float] = None
    margin_floor: Optional[float] = None
    slack_webhook_url: Optional[str] = None
    notify_email: Optional[str] = None
    large_change_threshold: Optional[float] = None

class ShopOut(BaseModel):
    id: int
    name: str
    platform: Optional[str] = None
    currency: str
    autopilot_enabled: Optional[bool] = False
    auto_approve: Optional[bool] = False
    max_increase_pct: Optional[float] = 0.10
    max_discount_pct: Optional[float] = 0.15
    margin_floor: Optional[float] = 0.25
    slack_webhook_url: Optional[str] = None
    notify_email: Optional[str] = None
    large_change_threshold: Optional[float] = 0.15
    class Config: from_attributes = True

class ProductCreate(BaseModel):
    shop_id: int
    sku: str
    name: str
    cost: float = 0.0
    price: float = 0.0
    min_price: float = 0.0
    max_price: float = 0.0
    stock: int = 0
    category: Optional[str] = "general"

class ProductOut(BaseModel):
    id: int
    shop_id: int
    sku: str
    name: str
    cost: float
    price: float
    min_price: float
    max_price: float
    stock: int
    category: Optional[str]
    class Config: from_attributes = True

class SuggestionOut(BaseModel):
    id: int
    product_id: int
    current_price: float
    suggested_price: float
    rationale: Optional[str]
    approved: bool
    created_at: datetime
    class Config: from_attributes = True

class ExperimentCreate(BaseModel):
    shop_id: int
    name: str

class ExperimentVariantCreate(BaseModel):
    experiment_id: int
    label: str
    price_delta_pct: float = 0.0
    traffic_split: float = 0.5
