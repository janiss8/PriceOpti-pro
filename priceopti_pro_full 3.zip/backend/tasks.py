import os
from celery import Celery
from celery.schedules import crontab
from sqlalchemy.orm import Session
from database import SessionLocal
from models import Shop, Product, PriceSuggestion
from price_engine import suggest_price
from notifications import send_slack, send_email

REDIS_URL=os.getenv("REDIS_URL","redis://localhost:6379/0")
celery_app=Celery("priceopti", broker=REDIS_URL, backend=REDIS_URL)

@celery_app.task
def autopilot_tick():
    db: Session = SessionLocal()
    try:
        shops=db.query(Shop).filter(Shop.autopilot_enabled==True).all()
        for shop in shops:
            products=db.query(Product).filter(Product.shop_id==shop.id).all()
            for p in products:
                metrics={"competitor_price": None, "demand_score":0.5, "stock_pressure":0.2, "margin_target":max(shop.margin_floor or 0.25,0.1), "max_increase_pct":shop.max_increase_pct or 0.10, "max_discount_pct":shop.max_discount_pct or 0.15}
                suggested, rationale=suggest_price(p, metrics)
                s=PriceSuggestion(product_id=p.id, current_price=p.price, suggested_price=suggested, rationale=rationale+" [autopilot]", approved=False)
                db.add(s); db.commit(); db.refresh(s)
                if shop.auto_approve:
                    change=abs(s.suggested_price - p.price) / (p.price or 1.0)
                    cap=(shop.max_increase_pct if s.suggested_price>=p.price else shop.max_discount_pct) or 0.15
                    if change <= cap:
                        s.approved=True; p.price=s.suggested_price; db.commit(); db.refresh(s)
                        # Notify on large change
                        threshold=shop.large_change_threshold or 0.15
                        if change>=threshold:
                            msg=f"[PriceOpti] Large price change for SKU {p.sku}: {p.price:.2f} -> {s.suggested_price:.2f} ({change*100:.1f}%)"
                            if shop.slack_webhook_url: send_slack(msg, webhook_url=shop.slack_webhook_url)
                            if shop.notify_email: send_email("PriceOpti alert", msg, to_email=shop.notify_email)
    finally:
        db.close()

celery_app.conf.timezone="Europe/Zurich"
celery_app.conf.beat_schedule={
    "autopilot-every-30": {"task":"tasks.autopilot_tick","schedule":crontab(minute="*/30")},
    "autopilot-0300": {"task":"tasks.autopilot_tick","schedule":crontab(minute=0,hour=3)},
}
