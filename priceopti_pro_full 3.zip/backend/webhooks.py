import os, hmac, hashlib, base64, json
from fastapi import APIRouter, Request, HTTPException, Depends
from sqlalchemy.orm import Session
from database import get_db
from models import Product
router=APIRouter(prefix="/webhooks", tags=["webhooks"])
SHOPIFY_SECRET=os.getenv("SHOPIFY_WEBHOOK_SECRET","")
def verify(raw: bytes, hmac_header: str):
    if not SHOPIFY_SECRET: return True
    digest=hmac.new(SHOPIFY_SECRET.encode(), raw, hashlib.sha256).digest()
    return hmac.compare_digest(base64.b64encode(digest).decode(), hmac_header or "")
@router.post("/shopify/products_update")
async def shopify_products_update(request: Request, db: Session = Depends(get_db)):
    raw=await request.body()
    if not verify(raw, request.headers.get("X-Shopify-Hmac-Sha256") or request.headers.get("x-shopify-hmac-sha256")):
        raise HTTPException(401, "Invalid HMAC")
    data=json.loads(raw.decode())
    for v in data.get("variants", []):
        sku=v.get("sku"); price=v.get("price")
        if sku and price is not None:
            p=db.query(Product).filter(Product.sku==sku).first()
            if p: p.price=float(price)
    db.commit(); return {"ok": True}
