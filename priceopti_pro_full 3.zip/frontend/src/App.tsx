import { useState } from 'react'
import Navbar from './components/Navbar'
import Dashboard from './pages/Dashboard'
import Products from './pages/Products'
import Suggestions from './pages/Suggestions'
import Settings from './pages/Settings'
import Experiments from './pages/Experiments'
import Auth from './pages/Auth'
import Billing from './pages/Billing'
import Competitors from './pages/Competitors'

export default function App(){
  const [route,setRoute]=useState<'auth'|'dashboard'|'products'|'suggestions'|'experiments'|'competitors'|'billing'|'settings'>('auth')
  return (<div className="min-h-screen">
    <Navbar onNavigate={setRoute}/>
    <main className="max-w-6xl mx-auto p-4">
      {route==='auth' && <Auth onSuccess={()=>setRoute('dashboard')}/>}
      {route==='dashboard' && <Dashboard/>}
      {route==='products' && <Products/>}
      {route==='suggestions' && <Suggestions/>}
      {route==='experiments' && <Experiments/>}
      {route==='competitors' && <Competitors/>}
      {route==='billing' && <Billing/>}
      {route==='settings' && <Settings/>}
    </main>
  </div>)
}