type Props={title:string,value:string}
export default function Card({title,value}:Props){ return (<div className="bg-white rounded-2xl p-5 shadow-sm border">
  <div className="text-sm text-gray-500">{title}</div><div className="mt-1 text-2xl font-semibold">{value}</div></div>) }