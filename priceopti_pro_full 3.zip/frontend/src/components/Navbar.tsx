type Props={onNavigate:(r:any)=>void}
export default function Navbar({onNavigate}:Props){
  return (<header className="bg-white border-b"><div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
    <div className="font-bold text-lg">PriceOpti<span className="text-blue-600">.ai</span></div>
    <nav className="flex gap-4 text-sm">
      <button onClick={()=>onNavigate('auth')} className="hover:text-blue-600">Auth</button>
      <button onClick={()=>onNavigate('dashboard')} className="hover:text-blue-600">Dashboard</button>
      <button onClick={()=>onNavigate('products')} className="hover:text-blue-600">Products</button>
      <button onClick={()=>onNavigate('suggestions')} className="hover:text-blue-600">Suggestions</button>
      <button onClick={()=>onNavigate('experiments')} className="hover:text-blue-600">Experiments</button>
      <button onClick={()=>onNavigate('competitors')} className="hover:text-blue-600">Competitors</button>
      <button onClick={()=>onNavigate('billing')} className="hover:text-blue-600">Billing</button>
      <button onClick={()=>onNavigate('settings')} className="hover:text-blue-600">Settings</button>
    </nav>
  </div></header>)
}