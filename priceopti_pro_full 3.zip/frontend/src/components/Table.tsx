type Column<T>={key:keyof T,label:string}
type Props<T>={columns:Column<T>[],data:T[]}
export default function Table<T extends {[k:string]:any}>({columns,data}:Props<T>){
  return (<div className="overflow-x-auto bg-white rounded-2xl border"><table className="w-full text-sm">
    <thead className="bg-gray-50 text-gray-600"><tr>{columns.map(c=><th key={String(c.key)} className="text-left px-4 py-2 border-b">{c.label}</th>)}</tr></thead>
    <tbody>{data.map((row,i)=>(<tr key={i} className="odd:bg-white even:bg-gray-50">
      {columns.map(c=><td key={String(c.key)} className="px-4 py-2 border-b">{String(row[c.key])}</td>)}
    </tr>))}</tbody></table></div>)
}