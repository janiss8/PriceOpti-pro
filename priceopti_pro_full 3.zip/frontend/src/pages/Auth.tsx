import {useState} from 'react'; import axios from 'axios'
export default function Auth({onSuccess}:{onSuccess:()=>void}){
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('')
  const base='http://localhost:8000'
  const save=(t:string)=>{localStorage.setItem('token',t); onSuccess()}
  const register=()=>axios.post(base+'/auth/register',{email,password}).then(r=>save(r.data.access_token)).catch(e=>alert(e.response?.data?.detail||'error'))
  const login=()=>axios.post(base+'/auth/login',{email,password}).then(r=>save(r.data.access_token)).catch(e=>alert(e.response?.data?.detail||'error'))
  return (<div className="max-w-md mx-auto bg-white border rounded-2xl p-6 space-y-3">
    <h2 className="text-lg font-semibold">Login / Register</h2>
    <input className="w-full border rounded-lg px-3 py-2" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)}/>
    <input className="w-full border rounded-lg px-3 py-2" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)}/>
    <div className="flex gap-2"><button className="btn" onClick={login}>Login</button><button className="px-4 py-2 rounded-lg border" onClick={register}>Register</button></div>
  </div>)
}