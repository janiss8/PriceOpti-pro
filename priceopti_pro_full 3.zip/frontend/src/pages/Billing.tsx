import { useState } from 'react'; import axios from 'axios'
export default function Billing(){
  const token=localStorage.getItem('token')||''; const headers={Authorization:`Bearer ${token}`}
  const [loading,setLoading]=useState(false)
  const checkout=()=>{ setLoading(true); axios.post('http://localhost:8000/billing/checkout',{}, {headers}).then(r=>window.location.href=r.data.checkout_url).catch(e=>{alert(e.response?.data?.detail||'Stripe not configured'); setLoading(false)}) }
  return (<div className="max-w-md bg-white border rounded-2xl p-5 space-y-3">
    <h2 className="text-lg font-semibold">Billing</h2><p className="text-sm text-gray-600">Subscribe to PriceOpti Pro (cancel anytime)</p>
    <button className="btn" disabled={loading} onClick={checkout}>{loading?'Redirecting…':'Subscribe – CHF 199/mo'}</button>
  </div>)
}