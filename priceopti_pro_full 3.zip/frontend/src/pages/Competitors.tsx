import { useState } from 'react'; import axios from 'axios'
export default function Competitors(){
  const token=localStorage.getItem('token')||''; const headers={Authorization:`Bearer ${token}`}
  const [file,setFile]=useState<File|undefined>(); const [shopId,setShopId]=useState(1); const [msg,setMsg]=useState('')
  const upload=()=>{ if(!file) return; const form=new FormData(); form.append('file',file); axios.post(`http://localhost:8000/competitors/upload?shop_id=${shopId}`, form, {headers}).then(r=>setMsg(`Uploaded ${r.data.rows} rows`)).catch(e=>setMsg(e.response?.data?.detail||'error')) }
  return (<div className="max-w-md bg-white border rounded-2xl p-5 space-y-3">
    <h2 className="text-lg font-semibold">Competitor Feed</h2><div className="text-sm text-gray-600">CSV: sku,price,competitor</div>
    <input type="number" value={shopId} onChange={e=>setShopId(parseInt(e.target.value))} className="w-full border rounded-lg px-3 py-2"/>
    <input type="file" accept=".csv" onChange={e=>setFile(e.target.files?.[0])}/><button className="btn" onClick={upload}>Upload CSV</button>
    {msg && <div className="text-sm">{msg}</div>}
  </div>)
}