import Card from '../components/Card'
export default function Dashboard(){
  return (<div className="grid md:grid-cols-4 gap-4">
    <Card title="Shops" value="1"/><Card title="Products" value="42"/><Card title="Open Suggestions" value="12"/><Card title="AB Tests Active" value="1"/>
  </div>)
}