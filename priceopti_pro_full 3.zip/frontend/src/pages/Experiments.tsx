import { useState } from 'react'; import axios from 'axios'
export default function Experiments(){
  const token=localStorage.getItem('token')||''; const headers={Authorization:`Bearer ${token}`}
  const [name,setName]=useState('Weekend Test'); const [expId,setExpId]=useState<number|undefined>()
  const create=()=>axios.post('http://localhost:8000/experiments',{shop_id:1,name},{headers}).then(r=>setExpId(r.data.id))
  const addVar=(label:string,delta:number,split:number)=>axios.post('http://localhost:8000/experiments/variant',{experiment_id:expId,label,price_delta_pct:delta,traffic_split:split},{headers})
  return (<div className="space-y-4 max-w-md">
    <div className="bg-white border rounded-2xl p-5 space-y-2">
      <h2 className="text-lg font-semibold">A/B Pricing</h2>
      <input className="w-full border rounded-lg px-3 py-2" value={name} onChange={e=>setName(e.target.value)} placeholder="Experiment name"/>
      <button className="btn" onClick={create}>Create Experiment</button>
      {expId && <div className="text-sm text-gray-600">Experiment #{expId} created</div>}
      {expId && <div className="flex gap-2">
        <button className="px-3 py-2 rounded-lg border" onClick={()=>addVar('A',0.00,0.5)}>Add A (0%)</button>
        <button className="px-3 py-2 rounded-lg border" onClick={()=>addVar('B',0.05,0.5)}>Add B (+5%)</button>
      </div>}
    </div>
  </div>)
}