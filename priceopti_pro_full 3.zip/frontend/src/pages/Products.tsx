import { useEffect, useState } from 'react'; import axios from 'axios'; import Table from '../components/Table'
type Product={id:number,shop_id:number,sku:string,name:string,cost:number,price:number,min_price:number,max_price:number,stock:number,category:string}
export default function Products(){
  const [rows,setRows]=useState<Product[]>([]); const token=localStorage.getItem('token')||''; const headers={Authorization:`Bearer ${token}`}
  useEffect(()=>{ if(!token) return; axios.get('http://localhost:8000/products',{headers}).then(r=>setRows(r.data)) },[])
  return (<div className="space-y-4">
    <div className="text-sm text-gray-500">Products from API</div>
    <Table<Product> columns={[{key:'sku',label:'SKU'},{key:'name',label:'Name'},{key:'price',label:'Price'},{key:'min_price',label:'Min'},{key:'max_price',label:'Max'},{key:'stock',label:'Stock'}]} data={rows}/>
  </div>)
}