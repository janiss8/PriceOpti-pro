import { useEffect, useState } from 'react'; import axios from 'axios'
type Shop={id:number,name:string,currency:string,autopilot_enabled?:boolean,auto_approve?:boolean,max_increase_pct?:number,max_discount_pct?:number,margin_floor?:number,slack_webhook_url?:string,notify_email?:string,large_change_threshold?:number}
export default function Settings(){
  const [token,setToken]=useState(localStorage.getItem('token')||'')
  const [shops,setShops]=useState<Shop[]>([])
  const headers=token?{Authorization:`Bearer ${token}`}:{}
  const load=()=>{ if(!token) return; axios.get('http://localhost:8000/shops',{headers}).then(r=>setShops(r.data)) }
  const saveToken=()=>{localStorage.setItem('token',token); load()}
  const update=(id:number,data:any)=>axios.put(`http://localhost:8000/shops/${id}`,data,{headers}).then(load)
  useEffect(()=>{ load() },[token])
  return (<div className="space-y-6 max-w-3xl">
    <div className="bg-white rounded-2xl border p-5 space-y-3">
      <h2 className="text-lg font-semibold">API Token</h2>
      <input className="w-full border rounded-lg px-3 py-2" value={token} onChange={e=>setToken(e.target.value)} placeholder="Paste Bearer token"/>
      <button className="btn" onClick={saveToken}>Save Token</button>
    </div>
    <div className="bg-white rounded-2xl border p-5">
      <h2 className="text-lg font-semibold mb-4">Autopilot & Alerts</h2>
      {!shops.length && <div className="text-sm text-gray-500">No shops yet. Create one via API.</div>}
      <div className="space-y-4">{shops.map(s=>(<div key={s.id} className="border rounded-xl p-4">
        <div className="font-medium">{s.name} <span className="text-gray-500 text-sm">({s.currency})</span></div>
        <div className="mt-3 grid md:grid-cols-3 gap-3 items-center">
          <label className="flex items-center gap-2"><input type="checkbox" checked={!!s.autopilot_enabled} onChange={e=>update(s.id,{autopilot_enabled:e.target.checked})}/><span>Enable Autopilot</span></label>
          <label className="flex items-center gap-2"><input type="checkbox" checked={!!s.auto_approve} onChange={e=>update(s.id,{auto_approve:e.target.checked})}/><span>Auto-approve safe changes</span></label>
          <div />
        </div>
        <div className="mt-3 grid md:grid-cols-3 gap-3">
          <div><div className="text-xs text-gray-500 mb-1">Max Increase %</div><input type="number" step="0.01" className="w-full border rounded-lg px-3 py-2" value={s.max_increase_pct??0.1} onChange={e=>update(s.id,{max_increase_pct:parseFloat(e.target.value)})}/></div>
          <div><div className="text-xs text-gray-500 mb-1">Max Discount %</div><input type="number" step="0.01" className="w-full border rounded-lg px-3 py-2" value={s.max_discount_pct??0.15} onChange={e=>update(s.id,{max_discount_pct:parseFloat(e.target.value)})}/></div>
          <div><div className="text-xs text-gray-500 mb-1">Margin Floor</div><input type="number" step="0.01" className="w-full border rounded-lg px-3 py-2" value={s.margin_floor??0.25} onChange={e=>update(s.id,{margin_floor:parseFloat(e.target.value)})}/></div>
        </div>
        <div className="mt-3 grid md:grid-cols-3 gap-3">
          <div><div className="text-xs text-gray-500 mb-1">Slack Webhook URL</div><input className="w-full border rounded-lg px-3 py-2" value={s.slack_webhook_url||''} onChange={e=>update(s.id,{slack_webhook_url:e.target.value})}/></div>
          <div><div className="text-xs text-gray-500 mb-1">Alert Email</div><input className="w-full border rounded-lg px-3 py-2" value={s.notify_email||''} onChange={e=>update(s.id,{notify_email:e.target.value})}/></div>
          <div><div className="text-xs text-gray-500 mb-1">Large Change Threshold</div><input type="number" step="0.01" className="w-full border rounded-lg px-3 py-2" value={s.large_change_threshold??0.15} onChange={e=>update(s.id,{large_change_threshold:parseFloat(e.target.value)})}/></div>
        </div>
      </div>))}</div>
    </div>
  </div>)
}