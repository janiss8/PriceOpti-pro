import { useEffect, useState } from 'react'; import axios from 'axios'
type Suggestion={id:number,product_id:number,current_price:number,suggested_price:number,rationale:string,approved:boolean,created_at:string}
export default function Suggestions(){
  const [rows,setRows]=useState<Suggestion[]>([])
  const token=localStorage.getItem('token')||''; const headers={Authorization:`Bearer ${token}`}
  const load=()=>axios.get('http://localhost:8000/suggestions',{headers}).then(r=>setRows(r.data))
  const runAgent=()=>axios.post('http://localhost:8000/agent/run',{}, {headers}).then(load)
  const approve=(id:number)=>axios.post(`http://localhost:8000/suggestions/${id}/approve`,{}, {headers}).then(load)
  useEffect(()=>{ if(token) load() },[])
  return (<div className="space-y-4">
    <div className="flex gap-2"><button className="btn" onClick={runAgent}>Run Agent</button></div>
    <div className="space-y-2">{rows.map(r=>(<div key={r.id} className="bg-white border rounded-xl p-3 flex items-center justify-between">
      <div><div className="font-medium">#{r.id} → CHF {r.suggested_price.toFixed(2)}</div><div className="text-xs text-gray-500">{r.rationale}</div></div>
      {!r.approved ? <button className="px-3 py-2 rounded-lg bg-emerald-600 text-white" onClick={()=>approve(r.id)}>Approve</button> : <span className="text-xs text-emerald-700">Applied</span>}
    </div>))}</div>
  </div>)
}